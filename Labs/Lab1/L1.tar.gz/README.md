Limitations: A limitation to this program is that the array that stores the word count for each line of the poem is size 200 and can only store the word count for 200 lines of the poem.

Assumptions: Poem ends when a user inputs a period character on a new line.

