#define TRUE 1
#define FALSE 0

int letter_count(char *);
int * create_freq_table();
void add_letters(int *, char *);
int char_count(char *word);
int encode(char c, int shift);