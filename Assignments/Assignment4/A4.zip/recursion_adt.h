int nth(Sorted_List *list, int n, double *key, int *value);
int nth_sorted(Sorted_List *list, int n, double *key, int *value);
int remove_nth(Sorted_List *list, int n, double *key, int *value);
