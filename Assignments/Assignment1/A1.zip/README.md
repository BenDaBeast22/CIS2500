Files: 
file_size.c 
read_words.c 
print_words.c
alphabetical_word_count.c
print_alphabetical_word_count.c
create_alphabetical_array.c
free_alphabetical_array.c
print_words_alphabetically.c
free_alphabetical_word_count.c
free_sptr.c
alphabetical_printing.c
alphabetical_printing.h
README.md
Makefile

Compilation:
To use the make file enter "make alphabetical_printing" and use "make clean" to clean the file

