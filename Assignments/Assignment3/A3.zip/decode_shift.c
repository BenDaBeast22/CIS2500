
int decode_shift(char *inputString){

    int i;
    int shift;

    for(i = 0; i < 26; i++){

        
    }

}