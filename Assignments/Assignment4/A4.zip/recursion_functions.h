int countup(int n, int m);
int countdown(int n);
int nth_recursive_method(Node *node, int n, double *key, int *value);
int nth_recursive_method_sorted(Node *node, int n, double *key, int *value);
int remove_nth_recursive_method(Node *node, int n, double *key, int *value);
