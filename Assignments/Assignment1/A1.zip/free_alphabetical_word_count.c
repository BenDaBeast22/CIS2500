#include <stdlib.h>

/**
 * Frees alphabetical_word_count
 */

void free_alphabetical_word_count(int *alphabetCount){
    
    free(alphabetCount);

}